--[[ Meta-Data
Meta-Data-Version: 1.0

Code-Name: Alert_ProcessOutsideCommands
Code-Type: LUA Function
Code-Version: 1.0
Code-Description: Alerts Kairen that the previous command has been processed; aka send the next command.
Code-Author: Robert Randazzio
]]--
return (
function ()

end
);